/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai;

import ispotifai.core.Bancos.BancoDiretorios;
import ispotifai.core.Bancos.BancoMusicas;
import ispotifai.core.Bancos.BancoPlaylists;
import ispotifai.core.PageSwitcher;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author jeffersonmourak
 */
public class IsPotiFai extends Application {
    public static PageSwitcher ps = new PageSwitcher();
    public static BancoPlaylists playlistsDB;
    public static BancoDiretorios dirDB;
    public static BancoMusicas musicDB;
    public static String home = System.getProperty("user.home");
    static {
        try {
            IsPotiFai.dirDB = new BancoDiretorios(IsPotiFai.home + "/.ispotifai/diretorios.txt", IsPotiFai.home + "/.ispotifai/musicas.txt");
        } catch (IOException ex) {
            Logger.getLogger(IsPotiFai.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            IsPotiFai.musicDB = new BancoMusicas(IsPotiFai.home + "/.ispotifai/musicas.txt");
        } catch (IOException ex) {
            Logger.getLogger(IsPotiFai.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            IsPotiFai.playlistsDB = new BancoPlaylists(IsPotiFai.home + "/.ispotifai/playlists");
        } catch (IOException ex) {
            Logger.getLogger(IsPotiFai.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            ps.addPage("login", FXMLLoader.load(IsPotiFai.class.getResource("ui/views/login/view.fxml")));
        } catch (IOException ex) {
            Logger.getLogger(IsPotiFai.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            ps.addPage("main", FXMLLoader.load(IsPotiFai.class.getResource("ui/views/main/view.fxml")));
        } catch (IOException ex) {
            Logger.getLogger(IsPotiFai.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    @Override
    public void start(Stage stage) throws Exception {
        //ps.goTo("login");
        ps.goTo("main");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
