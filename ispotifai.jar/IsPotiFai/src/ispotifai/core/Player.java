/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.core;

/**
 *
 * @author jeffersonmourak
 */
import java.io.File;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class Player {
	private String filename;
	private Media hit;
	private MediaPlayer mp;
	public Player(String filename) {
		this.setFilename(filename);
	}
	
        public MediaPlayer getMediaPlayer() {
            return this.mp;
        }
        
	public void play() {
		this.mp.play();
	}
	
	public void stop() {
		this.mp.stop();
	}
	public void pause() {
		this.mp.pause();
	}
	public void setFilename(String filename) {
		this.filename = filename;
		File file = new File(filename);
		this.hit = new Media(file.toURI().toString());
		this.mp = new MediaPlayer(this.hit);
	}
}
