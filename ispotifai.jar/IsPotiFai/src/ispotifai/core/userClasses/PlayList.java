/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.core.userClasses;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author nalbertg
 */
public class PlayList {
    private List<Musica> musicList;
    private Integer IdPlaylist;
    private String IdDoUsuarioDono;

    public PlayList(String auxIdDoUsuarioDono) {
        this.IdDoUsuarioDono = auxIdDoUsuarioDono;
    }

    public PlayList(String IdPlaylist, ArrayList<Musica> ma) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getDonoDaPlaylist() {
        return IdDoUsuarioDono;
    }
    
    public void insertMusic(Musica auxMusica) {
        musicList.add(auxMusica);
    }
    
    public void removeMusic(Musica auxMusica) {
        musicList.remove(auxMusica);
    }

    public Integer getIdPlaylist() {
        return IdPlaylist;
    }

    public void setIdPlaylist(Integer IdPlaylist) {
        this.IdPlaylist = IdPlaylist;
    }
    
    
}
