/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.core.userClasses;

import java.util.ArrayList;
import java.util.List;
import ispotifai.core.binarySearchTree.BinarySearchTree;
import ispotifai.core.binarySearchTree.Node;

/**
 *
 * @author nalbertg
 */
public class Adiministrador extends Vip{
    /**
     * A propriedade usuarios é  uma arvore binaria que armazena os usuarios criados no sistema pelo adiministrador.
     */
    private BinarySearchTree<String, Usuario> usuarios;
    /**
     * A propriedade usuariosList é uma List que armazena Usuarios para facilidar o uso da função this.getUsuarioByName(), ou seja, para encontra o Usuario pelo nome;
     */
    private List<Usuario> usuariosList;
    
    /**
     * Esse é o construtor do adiministrador, o adiministrdor possui já por definição id igual a 1 e senha igual a 123.
     * @param name Esse é o parametro que vai receber o nome do adiministrador do sistema.
     */
    public Adiministrador(BinarySearchTree<String, Usuario> b) {
        super("1", "ADM", "123");
        this.usuarios = b;
        this.usuariosList = new ArrayList<Usuario>();
        
        this.usuarios.insert(this.id, this);
    }

    /**
     * è o metodo get da propriedade this.usuarios .
     * @return Retorna a ravore binaria que possui os Usuarios criados pelo adiministrador.
     */
    public BinarySearchTree<String, Usuario> getUsuarios() {
        return usuarios;
    }
    
    /**
     * Essa função serve para o Adiministrador criar um novo Usuario no sistema.
     * @param name  Esse parametroo recebe o nome desse usuario.
     * @throws Exception 
     */
    public void createNewUser(String name, String password) throws Exception {
        Usuario u = new Usuario(name, password);
        Node<String, Usuario> n = this.usuarios.search(u.getId());  
        while(n != null) {
            u = new Usuario(name, password);
            n = this.usuarios.search(u.getId());
        }
        this.usuarios.insert(u.getId(), u);
        this.usuariosList.add(u);
        
//        Usuario u2 = this.getUsuarioById(u.getId());
//        System.out.println(u2.getName());
//        System.out.println(u2.getId());
//        System.out.println(u2.getPassword());
    }
    
    /**
     * Essa função busca pelo o Usuario criado pelo nome.
     * @param name  Esse parametro é o nome do Usuario que se deve procurar.
     * @return Retorna o objeto Usuario com o nome procurado ou retorna null para caso o Usuario não exista
     */
    public Usuario getUsuarioByName(String name) {
        if(this.usuariosList.size() == 0) {
            return null;
        }
        else {
            for(Usuario u : this.usuariosList) {
                if(u.getName() == name) {
                    return u;
                }
            }
            return null;
        }
    }
    
    /**
     * Essa função procura na arvore um usuario com o id passado por parametro.
     * @param index  Recebe o id do usuario procurado
     * @return Retorna o objeto Usuario com o referido id, ou null para caso o usuario não exista
     * @throws Exception 
     */
    public Usuario getUsuarioById(String index) throws Exception {
        Node<String, Usuario> n =  this.usuarios.search(index);
        if(n != null) {
            return n.getData();
        }
        else {
            return null;
        }
    }
}
