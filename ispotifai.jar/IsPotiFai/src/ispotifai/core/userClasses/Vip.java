/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.core.userClasses;

/**
 *
 * @author nalbertg
 */
public class Vip extends Usuario{

    /**
     * Esse construtor é utilizado para definir o Adiministrador.
     * @param id        Recebe o id (Adiministrador por padrãao é 1).
     * @param name      Recebe o nome.
     * @param password  Recebe a senha (Adiministrador por padrãao é 123).
     */
    public Vip(String id, String name, String password) {
        super(id, name, password);
    }
    
    /**
     * Sobrescreve a função newPlayList() de Usuario para permitir o VIP criar quantas playLists ele quiser.
     */
    @Override
    public void newPlayList() {
        userPlayLists.add(new PlayList(this.id));
    }
}
