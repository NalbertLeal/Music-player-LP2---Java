/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.core.userClasses;

import ispotifai.core.Utils;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author nalbertg
 */
public class Usuario {
    
    private Utils utils = new Utils();
    
    /**
     * A propriedade id possui o id do Usuario no sistema (id vai de 1 até 2000000000).
     */
    protected String id;
    /**
     * A propriedade name armazena o nome do Usuario.
     */
    protected String name;
    /**
     * A propriedade password armazena a senha do Usuario.
     */
    protected String password;
    /**
     * A propriedade userPlayLists armazena as PlayList de um usuario (Usuario comun só possui 1 PlayList).
     */
    protected List<PlayList> userPlayLists;

    /**
     * Construtor padrão do Usuario, aki o usuario vai ser criado e seu id gerado automaticamente.
     * @param name      Recebe o nome do Usuario.
     * @param password  Recebe a senha do Usuario.
     * @throws java.io.UnsupportedEncodingException
     */
    public Usuario(String name, String password) throws UnsupportedEncodingException {
        this.id = utils.userHash(name);
        this.name = name;
        this.password = password;
        this.userPlayLists = new ArrayList<PlayList>();
    }

    /**
     * Construtor de Usuario geralmente usado para definir o adiministrador.
     * @param id        Recebe o id do Usuario (Adiministrador por padrãao é 1).
     * @param name      Recebe o nome do Usuario.
     * @param password  Recebe a senha do Usuario (Adiministrador por padrãao é 123).
     */
    public Usuario(String id, String name, String password) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.userPlayLists = new ArrayList<PlayList>();
    }
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    /**
     * Cria uma nova PlayList para esse usuario seoUsuario não tiver uma PlayList já criada.
     */
    public void newPlayList() {
        if(userPlayLists.size() < 1) {
            userPlayLists.add(new PlayList(this.id));
        }
    }
    
    public void insertPlayList(PlayList p) {
        userPlayLists.add(p);
    }
    
    /**
     * Deleta uma playList.
     * @param auxIdPlayList     Recebe o id da Playlist que vai ser deletada.
     */
    public void deletePlayList(Integer auxIdPlayList) {
        PlayList auxPlayList;
        for(PlayList p : userPlayLists) {
            if(p.getIdPlaylist().equals(auxIdPlayList)) {
                userPlayLists.remove(p);
            }
        }
    }
    
}
