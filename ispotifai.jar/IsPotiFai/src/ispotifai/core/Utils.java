
package ispotifai.core;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jeffersonmourak
 */
public class Utils {
    private Base64.Encoder encoder = Base64.getEncoder();
    
    public String userHash(String name) throws UnsupportedEncodingException {
        byte[] stringBytes = name.getBytes("ASCII");
        return encoder.encodeToString(stringBytes);
    } 
}
