/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.core.Bancos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import ispotifai.core.userClasses.Musica;

/**
 *
 * @author nalbertg
 */
public class BancoMusicas implements InterfaceBanco{
    public String musicasToWrite;
    public String musicasRead;
    public String usuariosPath;
    private File file;
    private FileReader fileReader;
    private BufferedReader fileBuffered;
    private FileWriter fileWriter;
    private ArrayList<Musica> musicasArray;
    
    public BancoMusicas(String path) throws IOException {
        this.usuariosPath = path;
        this.musicasToWrite = "";
        this.musicasRead = "";
        this.file = new File(this.usuariosPath);
        if(!this.file.exists()) {
            this.file.createNewFile();
        }
        
        this.fileReader = new FileReader(this.usuariosPath);
        this.fileBuffered = new BufferedReader(this.fileReader);
        this.fileWriter = null;
        this.musicasArray = new ArrayList<Musica>();
        
        this.read();
    }

    public ArrayList<Musica> getMusicasArray() {
        return musicasArray;
    }
    
    public String getMusicasRead() {
        return musicasRead;
    }

    public void setMusicasToWrite(String auxMusicasToWrite) {
        this.musicasToWrite = auxMusicasToWrite;
    }
    
    public void add(String proprerty, String value, boolean isLast) {
       if(this.musicasToWrite.length() == 0) {
            this.musicasToWrite = this.musicasToWrite + proprerty + ":" + value;
        }
        else if(isLast) {
            this.musicasToWrite = this.musicasToWrite + "," + proprerty + ":" + value + ";";
        }
        else {
            if(this.musicasToWrite.charAt(this.musicasToWrite.length()-1) == ';') {
                this.musicasToWrite = this.musicasToWrite + proprerty + ":" + value;
            }
            else {
                this.musicasToWrite = this.musicasToWrite + "," + proprerty + ":" + value;
            }
        }
    }
    
    public void write() {
        try {
            this.fileWriter = new FileWriter(this.usuariosPath);
            this.file.createNewFile();
        
            this.fileWriter.write(this.musicasToWrite);
            this.fileWriter.close();
        }
        catch(Exception e) {
            e.getMessage();
        }
    }
    
    public void read() {
        try {
            String linha = this.fileBuffered.readLine();
            this.musicasRead = this.musicasRead + linha;
            while (linha != null) {
                linha = this.fileBuffered.readLine(); // lê da segunda até a última linha
                if(linha != null) {
                    this.musicasRead = this.musicasRead + linha;
                }
            }
        }
        catch(Exception e) {
            e.getMessage();
        }
    }
    
    public ArrayList<Musica> organizeMusicsonArray() {
        int counterTwoPoints = 0;
        int index = 0;
        
        while(index < this.musicasRead.length()) {
            
            String auxMusica = "";
            while(index < this.musicasRead.length() && this.musicasRead.charAt(index) != ';') {
                auxMusica = auxMusica + this.musicasRead.charAt(index);
                index++;
            }
            index++;
            String auxName = "";
            String auxPath = "";
            int index2 = 0;
            
            // get id
            while(index2 < auxMusica.length() && auxMusica.charAt(index2) != ':') {
                index2++;
            }
            index2++;
            while(index2 < auxMusica.length() && auxMusica.charAt(index2) != ',') {
                auxName = auxName + auxMusica.charAt(index2);
                index2++;
            }
//            System.out.println(auxName);
            // get password
            while(index2 < auxMusica.length() && auxMusica.charAt(index2) != ':') {
                index2++;
            }
            index2++;
            while(index2 < auxMusica.length()) {
                auxPath = auxPath + auxMusica.charAt(index2);
                index2++;
            }
//            System.out.println(auxPath);
            Musica auxM = new Musica(auxName, auxPath);
            this.musicasArray.add(auxM);
//            System.out.println(auxM.getNome());
//            System.out.println(auxM.getPath());
        }
        
        System.out.println("" + musicasArray.size());
        for(Musica m : musicasArray) {
//            System.out.println(m.getNome());
//                System.out.println(m.getPath());
            if(m.getNome().equals("hard")) {
                System.out.println(m.getNome());
                System.out.println(m.getPath());
            }
            else if(m.getNome() == "sky") {
                System.out.println(m.getNome());
                System.out.println(m.getPath());
            }
        }
        
        return this.musicasArray;
    }
}
