/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.core.Bancos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author nalbertg
 */
public class BancoDiretorios implements InterfaceBanco{
    private String dataFileToWrite;
    private String musicaPath;
    private String dataFile;
    private String directoriesPath;
    private File file;
    private FileReader fileReader;
    private BufferedReader fileBuffered;
    private FileWriter fileWriter;

    public BancoDiretorios(String path, String musicasPath) throws IOException {
        this.directoriesPath = path;
        this.musicaPath = musicasPath;
        this.dataFile = "";
        this.dataFileToWrite = "";
        this.file = new File(this.directoriesPath);
        if(!this.file.exists()) {
            this.file.createNewFile();
        }
        this.fileReader = new FileReader(this.directoriesPath);
        this.fileBuffered = new BufferedReader(this.fileReader);
        this.fileWriter = null;
        
        this.read();
    }
    
    public void add(String toAdd) {
        this.dataFileToWrite = this.dataFileToWrite + toAdd + ";";
    }
    
    public void write() {
        try {
            this.fileWriter = new FileWriter(this.directoriesPath);
            this.file.createNewFile();
            
            //System.out.println(this.dataFileToWrite);
            
            this.fileWriter.write(this.dataFileToWrite);
            this.fileWriter.close();
        }
        catch(Exception e) {
            e.getMessage();
        }
    }
    
    public void read() {
        try {
            String linha = this.fileBuffered.readLine();
            while (linha != null) {
                this.dataFile = this.dataFile + linha;
                linha = this.fileBuffered.readLine(); // lê da segunda até a última linha
                if(linha != null) {
                    this.dataFile = this.dataFile + linha;
                }
            }
        }
        catch(Exception e) {
            e.getMessage();
        }
        //System.out.println(this.dataFile);
        
        int index = 0;
        while(index < this.dataFile.length()) {
            String aPath = "";
            while(index < this.dataFile.length() && this.dataFile.charAt(index) != ';') {
                aPath = aPath + this.dataFile.charAt(index);
                index++;
            }
            index++;
            
            try {
                UpdateMusicas um = new UpdateMusicas(this.musicaPath);
                um.verifyNewMusicas(aPath);
                um.writeNewFileMusica();
            }
            catch(Exception e) {
                e.getMessage();
            }
        }
    }
}
