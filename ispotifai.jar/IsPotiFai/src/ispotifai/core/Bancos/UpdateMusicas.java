/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.core.Bancos;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import ispotifai.core.userClasses.Musica;

/**
 *
 * @author nalbertg
 */
public class UpdateMusicas {
    private String musicasRead;
    private String newMusicas;
    private BancoMusicas bancoMusicas;
    private String musicaRead;
    
    public UpdateMusicas(String pathBancoMusicas) throws IOException {
        this.bancoMusicas = new BancoMusicas(pathBancoMusicas);
        this.musicasRead = this.bancoMusicas.getMusicasRead();
        if(this.musicasRead == null || this.musicasRead == "null") {
            this.musicasRead = "";
        }
        this.musicaRead = this.bancoMusicas.getMusicasRead();
        this.newMusicas = "";
    }
    
    public void verifyNewMusicas(String path) {
        File folder = new File(path);
        File[] files = folder.listFiles();
        String auxFileName = "";
        for(int index = 0; index < files.length; index++)  {
            String auxS = files[index].getPath();
            if(auxS.charAt(auxS.length()-3) == 'm' && (auxS.charAt(auxS.length()-2) == 'p' && auxS.charAt(auxS.length()-1) == '3')) {
                if(!this.musicasRead.toLowerCase().contains(files[index].getName().toLowerCase())) {    // aqui verifica se a musica é nova
                    auxFileName = auxFileName + "name:" + files[index].getName() + ",path:" + files[index].getPath() + ";";
                }
            }
        }
        if(auxFileName != "" && !auxFileName.equals("")) {
            this.newMusicas = this.newMusicas + auxFileName;
        }
        else {
            this.newMusicas = "";
        }
    }
    
    public void writeNewFileMusica() {
        String toWrite = "";
        System.out.println("" + this.musicaRead.equals("null") + " " + (this.newMusicas.length() == 0));
        if(this.musicaRead.equals("null") && this.newMusicas.length() == 0) {
            toWrite = "";
        }
        else if(this.musicaRead.equals("null") && this.newMusicas.length() > 0) {
            toWrite = this.newMusicas;
        }
        else if(!this.musicaRead.equals("null") && this.newMusicas.length() == 0) {;
            toWrite = this.musicaRead;
        }
        else if(!this.musicaRead.equals("null") && this.newMusicas.length() > 0) {
            toWrite = this.musicasRead + this.newMusicas;
        }
        
        this.bancoMusicas.setMusicasToWrite(toWrite);
        this.bancoMusicas.write();
    }
}
