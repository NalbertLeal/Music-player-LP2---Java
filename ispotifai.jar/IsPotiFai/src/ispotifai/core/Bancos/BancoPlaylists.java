/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.core.Bancos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import ispotifai.core.userClasses.Musica;
import ispotifai.core.userClasses.PlayList;

/**
 *
 * @author nalbertg
 */
public class BancoPlaylists {
    /**
     * Propriedade que armazena o path da pasta dos arquivos PlayList
     */
    private String pathPlayLists;
    /**
     * Propriedade que armazena um ArrayList com todas as Playlist mapeadas
     */
    private ArrayList<PlayList> playLists;
    /**
     * Propriedade que armazena o objeto da pasta com os arquios daas PlayList
     */
    private File folder;
    /**
     * Propriedade que armazena todos os objetos reprensentando arquivos com informações das PlayList
     */
    private File[] files;

    /**
     * Construtorde bancoPlayList recebe o path da pasta aonde se encontrão todos os arquivos de playlist
     * @param path  Parametro que recebe o path da pasta aonde estão os arquivos de PlayList.
     * @throws IOException 
     */
    public BancoPlaylists(String path) throws IOException {
        this.pathPlayLists = path;
        this.folder = new File(this.pathPlayLists);
        this.files = this.folder.listFiles();
    }
    
    public void addByPath(String path, String nameMusica, String pathMusica) throws IOException {
        File file = null;
        for(int index = 0; index < files.length; index++) {
            if(path == files[index].getPath()) {
                file = files[index];
            }
        }
        if(file != null) {
            FileReader fileReader = new FileReader(file);
            BufferedReader fileBuffered = new BufferedReader(fileReader);
            
            String line;
            line = fileBuffered.readLine();
            String auxPlayList = "";
            if(!line.equals(line)) {
                auxPlayList = auxPlayList + line;
            }
            while(line != null) {
                line = fileBuffered.readLine(); // lê da segunda até a última linha
                if(line != null && !line.equals("null")) {
                    auxPlayList = auxPlayList + line;
                }
            }
            
            FileWriter fileWriter = new FileWriter(file.getPath());
            if(auxPlayList.length() == 0) {
                fileWriter.write(auxPlayList + "name:" + nameMusica + ":path:" + pathMusica + ";");
            }
            else {
                fileWriter.write(auxPlayList + ";name:" + nameMusica + ":path:" + pathMusica + ";");
            }
        }
    }
    
    public void addByID(String idPlayList, String nameMusica, String pathMusica) throws IOException {
        File file = null;
        String firstLine = "";
        int firstComma = 0;
        for(int index = 0; index < files.length; index++) {
            FileReader fileReader = new FileReader(files[index].getPath());
            BufferedReader fileBuffered = new BufferedReader(fileReader);
            String line = "";
            line = fileBuffered.readLine();
            firstLine = "" + line;
            if(firstLine.equals("null") || (firstLine == null || firstLine.equals(""))) {
                continue;
            }
            int counterCommas = 0;
            int index2 = 0;
            String IdPlaylist2 = "";
            while(index2 < firstLine.length() && firstLine.charAt(index2) != ';') {
                IdPlaylist2 = IdPlaylist2 + firstLine.charAt(index2);
                index2++;
                firstComma = index2;
            }
            
            if(idPlayList.equals(IdPlaylist2)) {
                file = files[index];
                break;
            }
            else {
                file = null;
                continue;
            }
        }
        if(file != null) {
           
            FileWriter fileWriter = new FileWriter(file.getPath());
            fileWriter.write(firstLine + "name:" + nameMusica + ":path:" + pathMusica + ";");
            fileWriter.close();
        }
    }
    
    public void write(String idPlayList) throws IOException {
        String fileName;
        String numberNow = "";
        Integer numberNowI = 0;
        if(files.length != 0) {
            fileName = files[files.length-1].getName();
            for(int index = 8; index < 12; index++) {
                numberNow = numberNow + fileName.charAt(index);
            }
            numberNowI = Integer.parseInt(numberNow);
            numberNowI = numberNowI + 1;
            if(numberNowI < 10) {
                numberNow = "playlist000" + numberNowI + ".txt";
            }
            else if(numberNowI > 10 && numberNowI < 100) {
                numberNow = "playlist00" + numberNowI + ".txt";
            }
            else if(numberNowI > 100 && numberNowI < 1000) {
                numberNow = "playlist0" + numberNowI + ".txt";
            }
            else {
                numberNow = "playlist" + numberNowI + ".txt";
            }
        }
        else {
            numberNow = "playlist0001.txt";
        }
        File file = new File(this.pathPlayLists + "\\" + numberNow);
        file.createNewFile();
        
        FileWriter fileWrite = new FileWriter(this.pathPlayLists + "\\" + numberNow);
        fileWrite.write("" + idPlayList + ";");
        fileWrite.close();
    }

    public ArrayList<PlayList> read() throws IOException {
        ArrayList<PlayList> pl = new ArrayList<PlayList>(this.files.length);
        for(int index = 0; index < this.files.length; index++) {
            ArrayList<Musica> ma = new ArrayList<Musica>();
            File file = new File(this.files[index].getPath());
            
            FileReader fileReader = new FileReader(file);
            BufferedReader fileBuffered = new BufferedReader(fileReader);
            
            String line = "";
            line = fileBuffered.readLine();
            String auxPlayList = "";
            if(line != null && !line.equals("null")) {
                auxPlayList = auxPlayList + line;
            }
            while(line != null) {
                line = fileBuffered.readLine(); // lê da segunda até a última linha
                if(line != null && !line.equals("null")) {
                    auxPlayList = auxPlayList + line;
                }
            }
            
            int counterCommas = 0;
            int index2 = 0;
            String IdPlaylist = "";
            while(index2 < auxPlayList.length()) {
                
                String auxMusica = "";
                while(index2 < auxPlayList.length() && auxPlayList.charAt(index2) != ';') {
                    auxMusica = auxMusica + auxPlayList.charAt(index2);
                    index2++;
                }
                counterCommas++;
                if(counterCommas == 1) {
                    int index3 = 0;
                    while(index3 < auxMusica.length()) {
                        IdPlaylist = IdPlaylist + auxPlayList.charAt(index3);
                        index3++;
                    }
                    continue;
                }
                index2++;
                String auxName = "";
                String auxPath = "";
                int index3 = 0;
            
                // get name
                while(index3 < auxMusica.length() && auxMusica.charAt(index3) != ':') {
                    index3++;
                }
                index3++;
                while(index3 < auxMusica.length() && auxMusica.charAt(index3) != ',') {
                    auxName = auxName + auxMusica.charAt(index3);
                    index3++;
                }
                // get password
                while(index3 < auxMusica.length() && auxMusica.charAt(index3) != ':') {
                    index3++;
                }
                index3++;
                while(index3 < auxMusica.length()) {
                    auxPath = auxPath + auxMusica.charAt(index3);
                    index3++;
                }
            
                Musica auxM = new Musica(auxName, auxPath);
                ma.add(auxM);
            }
            pl.add(new PlayList(IdPlaylist, ma));
        }
        return pl;
    }
    
    public ArrayList<PlayList> getUserPlaylists(String id) throws IOException {
        ArrayList<PlayList> playlists = this.read();
        ArrayList<PlayList> userPlaylists = new ArrayList<PlayList>();
        for (PlayList playlist : playlists) {
            if (playlist.getDonoDaPlaylist().equals(id)) {
                userPlaylists.add(playlist);
            }
        }
        return userPlaylists;
    }
}
