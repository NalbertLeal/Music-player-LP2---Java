/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.core.Bancos;

import ispotifai.core.binarySearchTree.BinarySearchTree;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import ispotifai.core.userClasses.Usuario;

/**
 *
 * @author nalbertg
 */
public class BancoUsuarios implements InterfaceBanco{
    public String usuariosToWrite;
    public String usuariosRead;
    public String usuariosPath;
    private File file;
    private FileReader fileReader;
    private BufferedReader fileBuffered;
    private FileWriter fileWriter;
    public BinarySearchTree<String, Usuario> binaryTree;

    public BancoUsuarios(String path) throws IOException {
        this.usuariosPath = path;
        this.usuariosToWrite = "";
        this.usuariosRead = "";
        this.file = new File(this.usuariosPath);
        if(!this.file.exists()) {
            this.file.createNewFile();
        }
        
        this.fileReader = new FileReader(this.usuariosPath);
        this.fileBuffered = new BufferedReader(this.fileReader);
        this.fileWriter = null;
        this.binaryTree = new BinarySearchTree<String, Usuario>();
        
        this.read();
    }

    public BinarySearchTree<String, Usuario> getBinaryTree() {
        return binaryTree;
    }
    
    public void add(String proprerty, String value, boolean isLast) {
        if(this.usuariosToWrite.length() == 0) {
            this.usuariosToWrite = this.usuariosToWrite + proprerty + ":" + value;
        }
        else if(isLast) {
            this.usuariosToWrite = this.usuariosToWrite + "," + proprerty + ":" + value + ";";
        }
        else {
            if(this.usuariosToWrite.charAt(this.usuariosToWrite.length()-1) == ';') {
                this.usuariosToWrite = this.usuariosToWrite + proprerty + ":" + value;
            }
            else {
                this.usuariosToWrite = this.usuariosToWrite + "," + proprerty + ":" + value;
            }
        }
    }
    
    public void write() {
        try {
            this.fileWriter = new FileWriter(this.usuariosPath);
            this.file.createNewFile();
        
            this.fileWriter.write(this.usuariosToWrite);
            this.fileWriter.close();
        }
        catch(Exception e) {
            e.getMessage();
        }
    }
    
    public void read() {
        try {
            String linha = this.fileBuffered.readLine();
            this.usuariosRead = this.usuariosRead + linha;
            while (linha != null) {
                linha = this.fileBuffered.readLine(); // lê da segunda até a última linha
                if(linha != null) {
                    this.usuariosRead = this.usuariosRead + linha;
                }
            }
        }
        catch(Exception e) {
            e.getMessage();
        }
    }
    
    public void addUser(Usuario user) {
        this.binaryTree.insert(user.getId(), user);
        this.add("id", user.getId(), false);
        this.add("nome", user.getName(), false);
        this.add("password", user.getPassword(), false);
        this.write();
    }
    
    public BinarySearchTree<String, Usuario> putUsuariosOnBST() throws Exception {
        int counterTwoPoints = 0;
        int index = 0;
        
        while(index < this.usuariosRead.length()) {
            
            String auxUsuario = "";
            while(index < this.usuariosRead.length() && this.usuariosRead.charAt(index) != ';') {
                auxUsuario = auxUsuario + this.usuariosRead.charAt(index);
                index++;
            }
            index++;
            
            String auxIdS = "";
            String auxName = "";
            String auxPassword = "";
            int index2 = 0;
            // get id
            while(index2 < auxUsuario.length() && auxUsuario.charAt(index2) != ':') {
                index2++;
            }
            index2++;
            while(index2 < auxUsuario.length() && auxUsuario.charAt(index2) != ',') {
                auxIdS = auxIdS + auxUsuario.charAt(index2);
                index2++;
            }
            // get name
            while(index2 < auxUsuario.length() && auxUsuario.charAt(index2) != ':') {
                index2++;
            }
            index2++;
            while(index2 < auxUsuario.length() && auxUsuario.charAt(index2) != ',') {
                auxName = auxName + auxUsuario.charAt(index2);
                index2++;
            }
            // get password
            while(index2 < auxUsuario.length() && auxUsuario.charAt(index2) != ':') {
                index2++;
            }
            index2++;
            while(index2 < auxUsuario.length()) {
                auxPassword = auxPassword + auxUsuario.charAt(index2);
                index2++;
            }
            this.binaryTree.insert(auxIdS, new Usuario(auxIdS, auxName, auxPassword));
        }
        
        return this.binaryTree;
    }
}
