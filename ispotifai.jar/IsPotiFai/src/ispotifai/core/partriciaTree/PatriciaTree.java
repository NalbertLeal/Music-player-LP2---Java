/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.core.partriciaTree;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nalbertg
 */
public class PatriciaTree {
    private Node root;

    public PatriciaTree() {
        this.root = new Node();
    }

    public Node getRoot() {
        return root;
    }

    public void setRoot(Node root) {
        this.root = root;
    }
    /**
     * A função search faz uma busca na arvore pelo caminho que pode levar formar a palavra no. 
     * @param word  É um parametro do tipo String que recebe a palavra que será procurada na arvore.
     * @return Retorna o nó que representa o ultimo caractere da palavra ou retorna null caso a palavra não existe na arvore.
     */
    public Node search(String word) {
        if(this.root == null) {
            return null;
        }
        
        Node auxNode = this.root;
        for(int index = 0; index < word.length(); index++) {
            Character c = word.charAt(index);
            Node auxNode2 = auxNode.search(c);
            System.out.println(c);
            if(auxNode2 != null) {
                auxNode = auxNode2;
            }
            else {
                return null;
            }
        }
        return auxNode;
    }
    
    public void insert(String word) {
        Node lastNode = null;
        if(word != "") {
            Node auxNode = this.root;
            for(int index = 0; index < word.length(); index++) {
                Character c = word.charAt(index);
                Node auxNode2 = auxNode.search(c);
                if(auxNode2 != null) {
                    auxNode = auxNode2;
                }
                else {
                    Node auxNode3;
                    for(int index2 = index; index2 < word.length(); index2++) {
                        c = word.charAt(index2);
                        auxNode3 = new Node(c, auxNode);
                        auxNode.insertSon(auxNode3);
                        auxNode = auxNode3;
                        lastNode = auxNode3;
                    }
                    break;
                }
            }
        }
        lastNode.setFlag(true);
    }
    
    public List<String> predictWords(String word) {
        Node n = this.search(word);
        String auxString = word;
        int index = 0;
        List<String> auxList = new ArrayList<String>();
        while(n != null) {
            while(n.getFlag() != true || index < word.length()) {
            }
            auxList.add(auxString);
        }
        if(auxList.size() == 0) {
            return null;
        }
        else {
            return auxList;
        }        
    }
    
    public void remove() {
        
    }
}
