/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.core.partriciaTree;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nalbertg
 */
public class Node {
    /**
     * data é uma propriedade de Node que armazena o caractere que esse nó representa.
     */
    private Character data;
    /**
     * father é uma propriedade de Node que armazena o nó pai desse nó.
     */
    private Node father;
    /**
     * flag é uma propriedade de Node que indica se esse nó é o final de uma palavra ou não.
     */
    private Boolean flag;
    /**
     * sons é um ArryList que armazena todos os filhos desse nó.
     */
    private List<Node> sons;

    /**
     * Construtor vazio de node.
     */
    public Node() {
        this.data = '\0';
        this.father = null;
        this.sons = new ArrayList<Node>();
    }
    
    /**
     * Construtor de Node 
     * @param auxData 
     */
    public Node(Character auxData) {
        this.data = auxData;
        this.father = null;
        this.sons = new ArrayList<Node>();
    }
    
    public Node(Character auxData, Node auxFather) {
        this.data = auxData;
        this.father = auxFather;
        this.sons = new ArrayList<Node>();
    }

    public Character getData() {
        return data;
    }

    public void setData(Character data) {
        this.data = data;
    }

    public Node getFather() {
        return father;
    }

    public void setFather(Node father) {
        this.father = father;
    }

    public Boolean getFlag() {
        return flag;
    }

    public void setFlag(Boolean flag) {
        this.flag = flag;
    }
    
    /**
    *   Essa função busca um nó com o valor charactere passado no parametro.
    * @param auxdata    Esse parametro serve para informar a função o caractere do node filho que vai ser inserido.
    * @return Node  Se encontrar o nó procurado retorna esse nó, caso contrário retorna null.
    */
    public Node search(Character data) {
//        System.out.println(data);
        if(this.sons.size() == 0) {
            return null;
        }
        for(Node n : this.sons) {
            if(n.getData().compareTo(data) == 0) {
                return n;
            }
        }
        return null;
    }
    
    /**
    *   Essa função cria um novo nó com o valor charactere passado no parametro e coloca esse novo nó como filho (dentro do ArrayList).
    * @param auxdata    Esse parametro serve para informar a função o caractere do node filho que vai ser inserido.
    * @return void
    */
    public void insertSon(Character auxData) {
        Node n = this.search(auxData);
        if(n != null) {
            Node newNode = new Node(auxData, this);
            sons.add(newNode);
        }
    }
    
    /**
    *   Essa função cria um novo nó com o valor charactere passado no parametro e coloca esse novo nó como filho (dentro do ArrayList).
    * @param auxdata    Esse parametro serve para informar a função o caractere do node filho que vai ser inserido.
    * @return void
    */
    public void insertSon(Node auxNode) {
        Node n = this.search(auxNode.getData());
        if(n == null) {
            sons.add(auxNode);
        }
    }
    
    /**
    *   Essa função remove um nó com o valor charactere passado no parametro do ArrayList de seus filhos.
    * @param auxdata    Esse parametro serve para informar a função o caractere do node filho que vai ser removido.
    * @return void
    */
    public void remove(Character auxData) {
        Node auxNode = this.search(auxData);
        if(auxNode != null) {
            this.sons.remove(auxNode);
        }
    }
    
    public void print() {
        for(Node n : this.sons) {
            System.out.println(n.getData());
        }
    }
}
