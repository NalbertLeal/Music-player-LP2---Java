/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.core.binarySearchTree;

import java.lang.Comparable;

/**
 *
 * @author nalbertg
 */
public class BinarySearchTree<keyType extends Comparable<keyType>, dataType> {
    private Node<keyType, dataType> root;
    
    /**
     * Construtor vazio da arvore binária.
     */
    public BinarySearchTree() {
        this.root = null;
    }
    
    /**
     * Construtor que recebe chave e dado do Node raiz.
     * @param key   Recebe o valor da chave.
     * @param data  Recebe o valor do dado.
     */
    public BinarySearchTree(keyType key, dataType data) {
        this.root = new Node<keyType, dataType>(key, data);
    }
    
    /**
     * Construtor que recebe o Node raiz.
     * @param node Recebe o Node raiz.
     */
    public BinarySearchTree(Node<keyType, dataType> node) {
        this.root = node;
    }
    
    /**
     * Essa função faz a busca de um Node na arvore binária.
     * @param key           Recebe a chave do nó procurado.
     * @return              Retorna o Node com a chave procurada ou retorna null para caso esse nó não exista na arvore.
     * @throws Exception 
     */
    public Node<keyType, dataType> search(keyType key) throws Exception {
        if(this.root == null) {
            throw new Exception("The tree root is empty.");
        }
        else {
            Node<keyType, dataType> auxNode = searchRecursive(null, this.root, key);
            if(auxNode.getKey().equals(key)) {
                return auxNode;
            }
            else {
                return null;
            }
        }
    }
    
    /**
     * Essa é uma busca recursiva interna da arvore binária.
     * @param auxBefore
     * @param auxNode
     * @param key
     * @return Retorna o Node com a chave procurad ou null para caso contrário.
     */
    private Node<keyType, dataType> searchRecursive(Node<keyType, dataType> auxBefore, Node<keyType, dataType> auxNode, keyType key) {
        if(auxNode == null) {
            return auxBefore;
        }
        else {
            if(auxNode.getKey().equals(key)) {
                return auxNode;
            }
            else if(auxNode.getKey().compareTo(key) == -1) {
                return searchRecursive(auxNode, auxNode.getRigth(), key);
            }
            else {
                return searchRecursive(auxNode, auxNode.getLeft(), key);
            }
        }
    }
    
    /**
     * Essa função faz a inserção de um novo Node na arvore apartir da chave e do dado recebido.
     * @param key   Recebe a chave do node a ser inserido.
     * @param data  Recebe a dado do node a ser inserido.
     */
    public void insert(keyType key, dataType data) {
        if(this.root == null) {
            this.root = new Node<keyType, dataType>(key, data);
        }
        else {
            Node<keyType, dataType> auxNode = this.searchRecursive(null, this.root, key);
            if(!auxNode.getKey().equals(key)) {
                if(auxNode.compareTo(key) == -1) {
                    Node<keyType, dataType> newNode = new Node<keyType, dataType>(key, data, auxNode, null, null);
                    auxNode.setRigth(newNode);
                }
                else {
                    Node<keyType, dataType> newNode = new Node<keyType, dataType>(key, data, auxNode, null, null);
                    auxNode.setLeft(newNode);
                }
            }
        }
    }
    
    /**
     * Essa função remove da arvore binária o node com a chave passad por parametro.
     * @param key   recebe a chave do Node que deve ser removido.
     * @throws Exception 
     */
    public void remove(keyType key) throws Exception {
        if(this.root == null) {
            throw new Exception("The tree root is empty.");
        }
        else {
           Node<keyType, dataType> auxNode = this.searchRecursive(null, this.root, key);
            if(!auxNode.equals(key)) {
                if(auxNode.compareTo(key) == -1) {
                    auxNode.setRigth(null);
                }
                else {
                    auxNode.setLeft(null);
                }
            } 
        }
    }
    
    
}