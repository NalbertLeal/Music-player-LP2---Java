/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.core.binarySearchTree;

/**
 *
 * @author nalbertg
 */
public class Node<keyType extends Comparable<keyType>, dataType> {
    private keyType key;
    private dataType data;
    private Node<keyType, dataType> father;
    private Node<keyType, dataType> left;
    private Node<keyType, dataType> rigth;
    
    /**
     * Construtor vazio do Node
     */
    public Node() {
        this.left = null;
        this.rigth = null;
    }
    
    /**
     * Construtor de Node que recebe o valor da chave e valor do dado.
     * @param key   Recebe o valor da chave.
     * @param data  Recebe o valor do dado.
     */
    public Node(keyType key, dataType data) {
        this.key = key;
        this.data = data;
        this.left = null;
        this.rigth = null;
    }
    
    /**
     * Construtor de Node que recebe o valor da chave e valor do dado, o Node direito e o Node esquerdo.
     * @param key       Recebe o valor da chave.
     * @param data      Recebe o valor do dado.
     * @param left      Recebe o Node direito.
     * @param rigth     Recebe o Node esquerdo.
     */
    public Node(keyType key, dataType data, Node<keyType, dataType> left, Node<keyType, dataType> rigth) {
        this.key = key;
        this.data = data;
        this.left = left;
        this.rigth = rigth;
    }
    
    /**
     * Construtor de Node que recebe o valor da chave e valor do dado, o Node pai desse nó, o Node direito e o Node esquerdo.
     * @param key       Recebe o valor da chave.
     * @param data      Recebe o valor do dado.
     * @param father    Recebe o node pai desse nó.
     * @param left      Recebe o Node direito.
     * @param rigth     Recebe o Node esquerdo.
     */
    public Node(keyType key, dataType data, Node<keyType, dataType> father, Node<keyType, dataType> left, Node<keyType, dataType> rigth) {
        this.key = key;
        this.data = data;
        this.father = father;
        this.left = left;
        this.rigth = rigth;
    }
    
    public keyType getKey() {
        return this.key;
    }
    
    public void setKey(keyType key) {
        this.key = key;
    }
    
    public dataType getData() {
        return this.data;
    }
    
    public void setData(dataType data) {
        this.data = data;
    }
    
    public Node<keyType, dataType> getLeft() {
        return this.left;
    }
    
    public void setLeft(Node<keyType, dataType> node) {
        this.left = node;
    }
    
    public Node<keyType, dataType> getRigth() {
        return this.rigth;
    }
    
    public void setRigth(Node<keyType, dataType> node) {
        this.rigth = node;
    }
    
    private int comparacao(String key1, String key2) {
        if(key1.length() < key2.length()) {
            return 1;
        }
        else if(key1.length() > key2.length()) {
            return -1;
        }
        for(int index = 0; index < key1.length(); index++) {
            Character c1 = key1.charAt(index);
            Character c2 = key2.charAt(index);
            if(!c1.equals(c2)) {
                return c1.compareTo(c2);
            }
        }
        return 0;
    }
    
    public int compareTo(keyType key) {
        if(this.key instanceof String) {
            return comparacao((String) this.key, (String) key);
        }
        return this.getKey().compareTo(key);
    }
}
