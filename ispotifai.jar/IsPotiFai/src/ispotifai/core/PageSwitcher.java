/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.core;

import java.util.HashMap;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author jeffersonmourak
 */
public class PageSwitcher {
    private HashMap<String, Parent> pages = new HashMap<String, Parent>();
    
    public PageSwitcher() {
        
    }
    
    public void addPage(String name, Parent page){
        this.pages.put(name, page);
    }
    
    private void _goTo(String name, boolean hide, ActionEvent event) {
        try {
            Parent root1 = this.pages.get(name);
            Stage stage = new Stage();
            Scene scene = new Scene(root1);
            scene.getStylesheets().add("ispotifai/ui/style.css");
            stage.setScene(scene);
            stage.show();
            if (hide) {
                ((Node)(event.getSource())).getScene().getWindow().hide();
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    public void goTo(String name) {
        ActionEvent mockEvent = new ActionEvent();
        this._goTo(name, false, mockEvent);
    }
    public void goTo(String name, ActionEvent event) {
        this._goTo(name, true, event);
    }
}
