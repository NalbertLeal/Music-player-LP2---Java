/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.ui.views.login;

import ispotifai.core.Bancos.BancoUsuarios;
import ispotifai.core.Utils;
import ispotifai.core.binarySearchTree.BinarySearchTree;
import ispotifai.core.userClasses.Usuario;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author jeffersonmourak
 */
public class viewController implements Initializable {
    private BancoUsuarios users;
    private BinarySearchTree<String, Usuario> tree;
    
    /* Prepopulated classes */
    private Utils utils = new Utils();
    
    @FXML
    private TextField usernameField;
    @FXML
    private TextField passwordField;
    @FXML
    private Label errorLabel;
    

    public viewController() throws IOException, Exception {
        this.users = new BancoUsuarios("/Users/jeffersonmourak/Data/databases/users.txt");
        this.users.putUsuariosOnBST();
        this.tree = this.users.getBinaryTree();
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("ispotifai.ui.views.login.viewController.initialize()");
    }
    
    @FXML
    private void registerUser(ActionEvent event) throws UnsupportedEncodingException {
        String name = usernameField.getText();
        String password = passwordField.getText();
        Usuario newUser = new Usuario(name, password);
        this.users.addUser(newUser);
        this.tree = this.users.getBinaryTree();
    }
    
    @FXML
    private void login(ActionEvent event) throws UnsupportedEncodingException, Exception {
        String name = usernameField.getText();
        String password = passwordField.getText();
        String id = utils.userHash(name);
        try {
            Usuario loginUser = this.tree.search(id).getData();
            if (loginUser.getPassword().equals(password)) {
                ispotifai.IsPotiFai.ps.goTo("main", event);
            } else {
                errorLabel.setText("Incorrect Password");
                errorLabel.setVisible(true);
            }
        } catch (Exception e) {
            errorLabel.setText("User Not Found\nPlease click in Register\nto create a new account");
            errorLabel.setVisible(true);
        }
    }
    
}
