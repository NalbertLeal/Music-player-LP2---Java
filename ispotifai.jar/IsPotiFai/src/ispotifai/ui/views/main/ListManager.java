package ispotifai.ui.views.main;

import java.util.Arrays;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.util.Callback;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jeffersonmourak
 */

public class ListManager {
    private TableView table;
    public ListManager(TableView table) {
        this.table = table;
    }
    
    public void setData(String[][] dataArray) {
        this.table.getColumns().clear();
     
        
        ObservableList<String[]> data = FXCollections.observableArrayList();
        data.addAll(Arrays.asList(dataArray));
        data.remove(0);
        
        for (int i = 0; i < dataArray[0].length; i++) {
            TableColumn tc = new TableColumn(dataArray[0][i]);
            final int colNo = i;
            tc.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<String[], String>, ObservableValue<String>>() {
                @Override
                public ObservableValue<String> call(TableColumn.CellDataFeatures<String[], String> p) {
                    return new SimpleStringProperty((p.getValue()[colNo]));
                }
            });
            table.getColumns().add(tc);
        }
        
      table.setItems(data);
    }
    
}
