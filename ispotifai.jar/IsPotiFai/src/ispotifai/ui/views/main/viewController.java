/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ispotifai.ui.views.main;

import ispotifai.core.Player;
import ispotifai.core.userClasses.Musica;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.beans.Observable;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Slider;
import javafx.scene.control.TableView;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

/**
 *
 * @author jeffersonmourak
 */
public class viewController implements Initializable {
    
    private Date lastClickTime;
    
    @FXML
    private Slider timeSlider;
    @FXML
    private TableView musicsTable;
    @FXML
    private TableView playlistsTable;
    @FXML
    private Label label;
    @FXML
    private Button playButton;
    @FXML
    private ProgressBar trackProgress;
    
    //Methods
    private Player player;
    private boolean playing = false;
    private int selectedMusic = 0;
    
    private String[][] musics;
    private ArrayList<Musica> musicsArray;
    
    @FXML
    private void playMusic(ActionEvent event) {
        if (!playing) {
            player.play();
            playButton.getStyleClass().remove(1);
            playButton.getStyleClass().add("pause-button");
        } else {
            player.pause();
            playButton.getStyleClass().remove(1);
            playButton.getStyleClass().add("play-button");
        }
        this.playing = !this.playing;
    }
    
    @FXML
    private void pauseMusic(ActionEvent event) {
        player.pause();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ListManager musicsList = new ListManager(musicsTable);
        ListManager playlistList = new ListManager(playlistsTable);
        
        musicsArray = ispotifai.IsPotiFai.musicDB.organizeMusicsonArray();
        
        this.musics = new String[musicsArray.size()+1][1];
        this.musics[0][0] = "Nome";
        int i = 1;
        for(Musica m : musicsArray) {
            this.musics[i][0] = m.getNome();
            i++;
        }
        musicsList.setData(this.musics);
        player = new Player(this.musicsArray.get(0).getPath());
        
        MediaPlayer audioPlayer = player.getMediaPlayer();
        
        audioPlayer.currentTimeProperty().addListener((Observable observable) -> {
            Duration time = audioPlayer.getCurrentTime();
            Duration total = audioPlayer.getTotalDuration();
            
            if (!timeSlider.isValueChanging() &&
                    total.greaterThan(Duration.ZERO)){
                double progress = (double) (time.toMillis() / total.toMillis() * 100);
                timeSlider.setValue(progress);
                System.out.println(progress);
                if (progress > 99.3) {
                    this.nextMusic();
                }
                trackProgress.setProgress(progress / 100);
            }
        });

    timeSlider.valueChangingProperty().addListener((Observable ov) -> {
        audioPlayer.seek(audioPlayer.getTotalDuration()
                .multiply(timeSlider.getValue() / 100.0));
        });
    
    timeSlider.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
        trackProgress.setProgress(new_val.doubleValue() / 100);
        });
        
    }    
    Object temp;
    @FXML
    private void selectMusic(){
       this.selectedMusic = musicsTable.getSelectionModel().getSelectedIndex();
       this.changeMusic();
    }
    
    @FXML
    private void nextMusic() {
        int nextItem = (1 + this.selectedMusic) % this.musicsArray.size();
        this.selectedMusic = nextItem;
        this.changeMusic();
        this.player.play();
        playButton.getStyleClass().remove(1);
        playButton.getStyleClass().add("pause-button");
    }
    
    @FXML
    private void previousMusic(ActionEvent event) {
        int previousItem = ((this.selectedMusic - 1) + this.musicsArray.size()) % this.musicsArray.size();
        this.selectedMusic = previousItem;
        this.changeMusic();
        this.player.play();
        playButton.getStyleClass().remove(1);
        playButton.getStyleClass().add("pause-button");
    }
    
    private void changeMusic() {
        int row = this.selectedMusic;
        player.stop();
        playButton.getStyleClass().remove(1);
        playButton.getStyleClass().add("play-button");
        player.setFilename(this.musicsArray.get(row).getPath());
        
        MediaPlayer audioPlayer = player.getMediaPlayer();
        
        audioPlayer.currentTimeProperty().addListener((Observable observable) -> {
            Duration time = audioPlayer.getCurrentTime();
            Duration total = audioPlayer.getTotalDuration();
            
            if (!timeSlider.isValueChanging() &&
                    total.greaterThan(Duration.ZERO)){
                double progress = (double) (time.toMillis() / total.toMillis() * 100);
                timeSlider.setValue(progress);
                if (progress > 99.3) {
                    this.nextMusic();
                }
                trackProgress.setProgress(progress / 100);
            }
        });

        timeSlider.valueChangingProperty().addListener((Observable ov) -> {
            audioPlayer.seek(audioPlayer.getTotalDuration()
                    .multiply(timeSlider.getValue() / 100.0));
            });

        timeSlider.valueProperty().addListener((ObservableValue<? extends Number> ov, Number old_val, Number new_val) -> {
            trackProgress.setProgress(new_val.doubleValue() / 100);
            });
    }
}
